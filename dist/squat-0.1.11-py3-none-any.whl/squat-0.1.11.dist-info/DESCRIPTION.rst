spend quality and usage analysis tool


